--
-- PostgreSQL database dump
--

\restrict K6ib62BSOOtlu7ecMgGTL3nbuvgT0kWqHzHT2bHDhHiaQnMv7fAKnbKwHa8cwhy

-- Dumped from database version 15.4 (Debian 15.4-2.pgdg120+1)
-- Dumped by pg_dump version 16.10 (Debian 16.10-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: vector; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS vector WITH SCHEMA public;


--
-- Name: EXTENSION vector; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION vector IS 'vector data type and ivfflat and hnsw access methods';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: athena
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO athena;

--
-- Name: dict_history; Type: TABLE; Schema: public; Owner: athena
--

CREATE TABLE public.dict_history (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    word text NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);

ALTER TABLE ONLY public.dict_history FORCE ROW LEVEL SECURITY;


ALTER TABLE public.dict_history OWNER TO athena;

--
-- Name: dictionary_packages; Type: TABLE; Schema: public; Owner: athena
--

CREATE TABLE public.dictionary_packages (
    id uuid NOT NULL,
    name text NOT NULL,
    is_active boolean DEFAULT false
);

ALTER TABLE ONLY public.dictionary_packages FORCE ROW LEVEL SECURITY;


ALTER TABLE public.dictionary_packages OWNER TO athena;

--
-- Name: languages; Type: TABLE; Schema: public; Owner: athena
--

CREATE TABLE public.languages (
    code text NOT NULL,
    name text NOT NULL,
    is_active boolean DEFAULT true
);


ALTER TABLE public.languages OWNER TO athena;

--
-- Name: payment_gateways; Type: TABLE; Schema: public; Owner: athena
--

CREATE TABLE public.payment_gateways (
    id uuid NOT NULL,
    name text NOT NULL,
    is_active boolean DEFAULT true
);

ALTER TABLE ONLY public.payment_gateways FORCE ROW LEVEL SECURITY;


ALTER TABLE public.payment_gateways OWNER TO athena;

--
-- Name: reading_progress; Type: TABLE; Schema: public; Owner: athena
--

CREATE TABLE public.reading_progress (
    user_id uuid NOT NULL,
    book_id uuid NOT NULL,
    updated_at timestamp with time zone DEFAULT now(),
    progress numeric
);

ALTER TABLE ONLY public.reading_progress FORCE ROW LEVEL SECURITY;


ALTER TABLE public.reading_progress OWNER TO athena;

--
-- Name: translations; Type: TABLE; Schema: public; Owner: athena
--

CREATE TABLE public.translations (
    lang_code text NOT NULL,
    key text NOT NULL,
    value text NOT NULL
);


ALTER TABLE public.translations OWNER TO athena;

--
-- Name: user_sessions; Type: TABLE; Schema: public; Owner: athena
--

CREATE TABLE public.user_sessions (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    revoked boolean DEFAULT false
);

ALTER TABLE ONLY public.user_sessions FORCE ROW LEVEL SECURITY;


ALTER TABLE public.user_sessions OWNER TO athena;

--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: athena
--

COPY public.alembic_version (version_num) FROM stdin;
0001_init
\.


--
-- Data for Name: dict_history; Type: TABLE DATA; Schema: public; Owner: athena
--

COPY public.dict_history (id, user_id, word, created_at) FROM stdin;
\.


--
-- Data for Name: dictionary_packages; Type: TABLE DATA; Schema: public; Owner: athena
--

COPY public.dictionary_packages (id, name, is_active) FROM stdin;
\.


--
-- Data for Name: languages; Type: TABLE DATA; Schema: public; Owner: athena
--

COPY public.languages (code, name, is_active) FROM stdin;
\.


--
-- Data for Name: payment_gateways; Type: TABLE DATA; Schema: public; Owner: athena
--

COPY public.payment_gateways (id, name, is_active) FROM stdin;
\.


--
-- Data for Name: reading_progress; Type: TABLE DATA; Schema: public; Owner: athena
--

COPY public.reading_progress (user_id, book_id, updated_at, progress) FROM stdin;
00000000-0000-0000-0000-0000000000aa	00000000-0000-0000-0000-000000000001	2025-11-13 13:25:30.859318+00	0.5
00000000-0000-0000-0000-0000000000bb	00000000-0000-0000-0000-000000000001	2025-11-13 13:25:48.083541+00	0.5
00000000-0000-0000-0000-0000000000cc	00000000-0000-0000-0000-000000000001	2025-11-13 13:27:27.589889+00	0.7
\.


--
-- Data for Name: translations; Type: TABLE DATA; Schema: public; Owner: athena
--

COPY public.translations (lang_code, key, value) FROM stdin;
\.


--
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: public; Owner: athena
--

COPY public.user_sessions (id, user_id, created_at, revoked) FROM stdin;
\.


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: athena
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: dict_history dict_history_pkey; Type: CONSTRAINT; Schema: public; Owner: athena
--

ALTER TABLE ONLY public.dict_history
    ADD CONSTRAINT dict_history_pkey PRIMARY KEY (id);


--
-- Name: dictionary_packages dictionary_packages_pkey; Type: CONSTRAINT; Schema: public; Owner: athena
--

ALTER TABLE ONLY public.dictionary_packages
    ADD CONSTRAINT dictionary_packages_pkey PRIMARY KEY (id);


--
-- Name: languages languages_pkey; Type: CONSTRAINT; Schema: public; Owner: athena
--

ALTER TABLE ONLY public.languages
    ADD CONSTRAINT languages_pkey PRIMARY KEY (code);


--
-- Name: payment_gateways payment_gateways_pkey; Type: CONSTRAINT; Schema: public; Owner: athena
--

ALTER TABLE ONLY public.payment_gateways
    ADD CONSTRAINT payment_gateways_pkey PRIMARY KEY (id);


--
-- Name: reading_progress reading_progress_pkey; Type: CONSTRAINT; Schema: public; Owner: athena
--

ALTER TABLE ONLY public.reading_progress
    ADD CONSTRAINT reading_progress_pkey PRIMARY KEY (user_id, book_id);


--
-- Name: translations translations_pkey; Type: CONSTRAINT; Schema: public; Owner: athena
--

ALTER TABLE ONLY public.translations
    ADD CONSTRAINT translations_pkey PRIMARY KEY (lang_code, key);


--
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: athena
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (id);


--
-- Name: idx_dictionary_packages_active; Type: INDEX; Schema: public; Owner: athena
--

CREATE INDEX idx_dictionary_packages_active ON public.dictionary_packages USING btree (is_active);


--
-- Name: idx_reading_progress_user_book_updated; Type: INDEX; Schema: public; Owner: athena
--

CREATE INDEX idx_reading_progress_user_book_updated ON public.reading_progress USING btree (user_id, book_id, updated_at DESC);


--
-- Name: idx_translations_key; Type: INDEX; Schema: public; Owner: athena
--

CREATE INDEX idx_translations_key ON public.translations USING btree (key);


--
-- Name: idx_translations_lang; Type: INDEX; Schema: public; Owner: athena
--

CREATE INDEX idx_translations_lang ON public.translations USING btree (lang_code);


--
-- Name: translations translations_lang_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: athena
--

ALTER TABLE ONLY public.translations
    ADD CONSTRAINT translations_lang_code_fkey FOREIGN KEY (lang_code) REFERENCES public.languages(code) ON DELETE CASCADE;


--
-- Name: dict_history; Type: ROW SECURITY; Schema: public; Owner: athena
--

ALTER TABLE public.dict_history ENABLE ROW LEVEL SECURITY;

--
-- Name: dict_history dict_history_owner; Type: POLICY; Schema: public; Owner: athena
--

CREATE POLICY dict_history_owner ON public.dict_history USING ((user_id = (current_setting('app.user_id'::text))::uuid)) WITH CHECK ((user_id = (current_setting('app.user_id'::text))::uuid));


--
-- Name: dictionary_packages; Type: ROW SECURITY; Schema: public; Owner: athena
--

ALTER TABLE public.dictionary_packages ENABLE ROW LEVEL SECURITY;

--
-- Name: dictionary_packages dictionary_packages_admin; Type: POLICY; Schema: public; Owner: athena
--

CREATE POLICY dictionary_packages_admin ON public.dictionary_packages USING ((current_setting('app.role'::text, true) = 'admin'::text)) WITH CHECK ((current_setting('app.role'::text, true) = 'admin'::text));


--
-- Name: languages; Type: ROW SECURITY; Schema: public; Owner: athena
--

ALTER TABLE public.languages ENABLE ROW LEVEL SECURITY;

--
-- Name: languages languages_admin; Type: POLICY; Schema: public; Owner: athena
--

CREATE POLICY languages_admin ON public.languages USING ((current_setting('app.role'::text, true) = 'admin'::text)) WITH CHECK ((current_setting('app.role'::text, true) = 'admin'::text));


--
-- Name: payment_gateways; Type: ROW SECURITY; Schema: public; Owner: athena
--

ALTER TABLE public.payment_gateways ENABLE ROW LEVEL SECURITY;

--
-- Name: payment_gateways payment_gateways_admin; Type: POLICY; Schema: public; Owner: athena
--

CREATE POLICY payment_gateways_admin ON public.payment_gateways USING ((current_setting('app.role'::text, true) = 'admin'::text)) WITH CHECK ((current_setting('app.role'::text, true) = 'admin'::text));


--
-- Name: reading_progress; Type: ROW SECURITY; Schema: public; Owner: athena
--

ALTER TABLE public.reading_progress ENABLE ROW LEVEL SECURITY;

--
-- Name: reading_progress reading_progress_owner; Type: POLICY; Schema: public; Owner: athena
--

CREATE POLICY reading_progress_owner ON public.reading_progress USING ((user_id = (current_setting('app.user_id'::text))::uuid)) WITH CHECK ((user_id = (current_setting('app.user_id'::text))::uuid));


--
-- Name: translations; Type: ROW SECURITY; Schema: public; Owner: athena
--

ALTER TABLE public.translations ENABLE ROW LEVEL SECURITY;

--
-- Name: translations translations_admin; Type: POLICY; Schema: public; Owner: athena
--

CREATE POLICY translations_admin ON public.translations USING ((current_setting('app.role'::text, true) = 'admin'::text)) WITH CHECK ((current_setting('app.role'::text, true) = 'admin'::text));


--
-- Name: user_sessions; Type: ROW SECURITY; Schema: public; Owner: athena
--

ALTER TABLE public.user_sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: user_sessions user_sessions_owner; Type: POLICY; Schema: public; Owner: athena
--

CREATE POLICY user_sessions_owner ON public.user_sessions USING ((user_id = (current_setting('app.user_id'::text))::uuid)) WITH CHECK ((user_id = (current_setting('app.user_id'::text))::uuid));


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT USAGE ON SCHEMA public TO appuser;


--
-- Name: TABLE reading_progress; Type: ACL; Schema: public; Owner: athena
--

GRANT SELECT,INSERT,UPDATE ON TABLE public.reading_progress TO appuser;


--
-- PostgreSQL database dump complete
--

\unrestrict K6ib62BSOOtlu7ecMgGTL3nbuvgT0kWqHzHT2bHDhHiaQnMv7fAKnbKwHa8cwhy

